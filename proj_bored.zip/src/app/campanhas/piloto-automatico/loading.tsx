import { SiteHeader } from "@/components/menus/header";

export default function AutoPilot() {
  return (
    <>
      CARREGANDO
    </>
  );
}

AutoPilot.auth = true;
