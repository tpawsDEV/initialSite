export const siteConfig = {
    name: "Glutoes",
    url: "https://app.glutoes.com",
    ogImage: "https://ui.shadcn.com/og.jpg",
    description:
      "Fature mais, com menos esforco.",
    links: {
    },
  }
  
  export type SiteConfig = typeof siteConfig